import React from 'react'

const Logout = () => {
  return (
    <div>
        <button className="btn btn-outline btn-info">Info</button>
    </div>
  )
}

export default Logout
